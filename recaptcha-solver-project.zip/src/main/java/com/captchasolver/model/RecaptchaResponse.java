package com.captchasolver.model;

public class RecaptchaResponse {
    private boolean success;
    private String token;
    private String message;

    public RecaptchaResponse(boolean success, String token, String message) {
        this.success = success;
        this.token = token;
        this.message = message;
    }

    public boolean isSuccess() { return success; }
    public String getToken() { return token; }
    public String getMessage() { return message; }
}
