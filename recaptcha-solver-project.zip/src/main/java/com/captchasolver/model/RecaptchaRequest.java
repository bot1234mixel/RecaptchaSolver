package com.captchasolver.model;

public class RecaptchaRequest {
    private String url;
    private String siteKey;

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

    public String getSiteKey() { return siteKey; }
    public void setSiteKey(String siteKey) { this.siteKey = siteKey; }
}
