package com.captchasolver.service;

import org.springframework.stereotype.Service;

@Service
public class RecaptchaService {

    public String solveEnterprise(String url, String siteKey) {
        return "dummy-token-example";
    }
}
